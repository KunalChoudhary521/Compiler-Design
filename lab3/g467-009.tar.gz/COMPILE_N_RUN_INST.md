# Lab 3 - AST (Compiler467)

### How to run manual page:
```shell
1.  make man
```

### How to compile:
```shell
1.  make clean
2.  make compiler467
```

### How to run:
```shell
1.  (./compiler467 -Da < <input_file>) > <output_file>
```
