{float a = rsq(3.4);}

/*tests that pass:
test#1: Implict type conversion, wrong assignment or constructor call
{int a = 6.3;}
{float a = true;}
{bool c = 4.2;}
{bool c = 98;}

{ivec3 a = ivec3(14,8,3.3);}
{bvec4 a = bvec4(true,false,1.2,34);}
{vec2 a = vec2(1.23,true);}



*/


